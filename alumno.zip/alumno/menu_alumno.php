<?php
session_start();

if (!isset($_SESSION['idAlumno']) || $_SESSION['rol'] !== 'alumno') {
    // Si no, redirige al login
    header("Location: ../index.php");
    exit;
}


if (!isset($_SESSION['idAlumno']) || $_SESSION['rol'] !== 'alumno') {
    header("Location: ../login.php");
    exit();
}

$nombreAlumno = $_SESSION['nombre'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menú Alumno</title>
  <link rel="stylesheet" href="css/menu_alumno.css?v=1.0">
</head>
<body>

  <div class="contenedor">
    <div class="contenedor1">
      <video autoplay muted loop id="videoFondo">
        <source src="img/video.mp4" type="video/mp4">
      </video>

      <header>
        <div class="logo">CECYTEM</div>
        <nav class="navbar">
          <a href="asistencia.php">Asistencia</a>
          <a href="Perfil.php">Perfil</a>
          <a href="cerrar.php">Cerrar sesión</a>
        </nav>
      </header>

      <div class="saludo">
        <h1>Bienvenid@ <?php echo htmlspecialchars($nombreAlumno); ?></h1>
        <p>Explora tu espacio de alumno y sigue avanzando.</p>
      </div>
    </div>

    <div class="contenedor2">
      <h2>¡Hechale más ganas!</h2>
      <img src="img/descarga.jpeg" alt="Motivación">
    </div>
  </div>

</body>
</html>
